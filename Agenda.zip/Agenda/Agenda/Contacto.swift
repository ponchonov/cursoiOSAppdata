//
//  Contacto.swift
//  Agenda
//
//  Created by Héctor Cuevas Morfín on 7/5/16.
//  Copyright © 2016 AppData. All rights reserved.
//

import UIKit
import RealmSwift

class Contacto: NSObject {
    
    dynamic var name = ""
    dynamic var lng = 0.0
    dynamic var lat = 0.0
    dynamic var imageurl = ""
    dynamic var phoneHouse = ""
    dynamic var phoneWork = ""
}
